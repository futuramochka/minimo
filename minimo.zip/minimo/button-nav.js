var button=document.querySelector(".page-header__button-toggle");
var menu=document.querySelector(".nav-menu__list");
var hide=document.querySelector(".page-header__button-hide");

button.addEventListener('click', function(hel) {

    menu.classList.add("nav-menu");
    button.classList.add("button-toggle");
    hide.classList.add("button-hide");
  
});

hide.addEventListener('click', function(hel) {

        menu.classList.remove("nav-menu");
        button.classList.remove("button-toggle");
        hide.classList.remove("button-hide");
  
});