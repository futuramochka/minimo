<?php
//Принимаем постовые данные
$email=$_POST['email-field'];
//Тут указываем на какой ящик посылать письмо
$to = "dubenco@protonmail.com";
//Далее идет тема и само сообщение
// Тема письма
$subject = "Заявка с сайта";
// Сообщение письма
$message = "
Email пользователя: ".htmlspecialchars($email);
// Отправляем письмо при помощи функции mail();
$headers = "From: stastroi.ru <dubenco@protonmail.com>\r\nContent-type: text/html; charset=UTF-8 \r\n";
mail ($to, $subject, $message, $headers);
// Перенаправляем человека на страницу благодарности и завершаем скрипт
?>