<div class="articles__button">
    <button class="articles__button-load" type="button">Load more</button>
</div>