<section class="page-footer">
    <section class="page-footer__social social">
        <ul class="social__list">
            <li class="social__item"><a href="#" class="social__link social__link--fb"></a></li>
            <li class="social__item"><a href="#" class="social__link social__link--tw"></a></li>
            <li class="social__item"><a href="#" class="social__link social__link--in"></a></li>
        </ul>
    </section>
</section>