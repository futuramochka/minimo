<section class="page-main__articles">
    <ul class="articles">
        <li class="article-item">
            <img class="article-item__image" src="image/one.svg" width="474" alt="article">
            <p class="nav-menu__item lifestyle"><a href="">Lifestyle</a></p>
            <h3 class="article-item__header">More than just a music festival</h3>
            <p class="article-item__text">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
            </p>
        </li>
        <li class="article-item">
            <img class="article-item__image" src="image/two.svg" width="422" alt="article">
            <p class="nav-menu__item lifestyle"><a href="">Lifestyle</a></p>
            <h3 class="article-item__header">More than just a music festival</h3>
            <p class="article-item__text">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
            </p>
        </li>
    </ul>
    <?php require_once "button-articles.php"; ?>
</section>