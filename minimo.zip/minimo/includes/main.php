<main class="page-main">
            <section class="page-main__top-article">
                <article class="top-article">
                    <img class="top-article__image" src="image/title.svg" width="1060" alt="TopImage">
                    <p class="nav-menu__item photodiary"><a href="#">photodiary</a></p>
                    <div class="top-article__preview">
                        <h2 class="top-article__header">The perfect weekend getaway</h2>
                        <p class="top-article__text">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.
                        </p>
                    </div>
                    <p class="nav-menu__item comment "><a href="#">Leave a comment</a></p>
                </article>
            </section>
            <section class="page-main__articles">
                <ul class="articles">
                    <li class="article-item">
                        <img class="article-item__image" src="image/one.svg" width="474" alt="article">
                        <p class="nav-menu__item lifestyle"><a href="">Lifestyle</a></p>
                        <h3 class="article-item__header">More than just a music festival</h3>
                        <p class="article-item__text">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                        </p>
                    </li>
                    <li class="article-item">
                        <img class="article-item__image" src="image/two.svg" width="422" alt="article">
                        <p class="nav-menu__item lifestyle"><a href="">Lifestyle</a></p>
                        <h3 class="article-item__header">More than just a music festival</h3>
                        <p class="article-item__text">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                        </p>
                    </li>
                    <li class="article-item">
                        <img class="article-item__image" src="image/three.svg" width="488" alt="article">
                        <p class="nav-menu__item photodiary photodiary--left"><a href="">Photodiary</a></p>
                        <h3 class="article-item__header">More than just a music festival</h3>
                        <p class="article-item__text">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                        </p>
                    </li>
                    <li class="article-item">
                        <img class="article-item__image" src="image/four.svg" width="420" alt="article">
                        <p class="nav-menu__item photodiary photodiary--left"><a href="">Photodiary</a></p>
                        <h3 class="article-item__header">More than just a music festival</h3>
                        <p class="article-item__text">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                        </p>
                    </li>
                </ul>
            </section>
            <?php require_once "includes/newslater.php"; require_once "includes/articles.php"; ?>
            
        </main>
        <script src="button-nav.js"></script>
    </body>
</html>