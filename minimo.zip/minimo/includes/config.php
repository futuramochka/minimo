<?php

$config = array(
    'title' => 'minimø',
    'db' => array(
        'server' => 'localhost',
        'username' => 'root',
        'password' => '',
        'dbname' => 'minimo'
    )
)

?>
