<section class="newslater">
    <h2 class="newslater__title">Sign up for our newsletter!</h2>
    
    <form class="newslater__form" accept="/" method="POST">
        <input class="newslater__input-email" type="email" placeholder="Enter a valid email address" id="email-go" name="email-field">
        <button class="newslater__button" type="submit"><img src="image/sendicon.svg" width="30" height="40" alt="send"></button>
    </form>
</section>