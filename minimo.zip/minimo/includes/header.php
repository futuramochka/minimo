
    <body>
        <header class="page-header">
            <section class="wrapper-header">
                <a class="page-header__logo">
                    <h1 class="page-header__logo-title"><?php echo $config['title']; ?></h1>
                    <button class="page-header__button-toggle" type="button">&#9776;</button>
                    <button class="page-header__button-hide" type="button">&#10006;</button>
                </a>
                <nav class="page-haeder__menu">
                    <ul class="nav-menu__list">
                        <li class="nav-menu__item"><a href="/minimo/pages/lifestyle.php" target="_blank">lifestyle</a></li>
                        <li class="nav-menu__item"><a href="/minimo/pages/photodiary.php" target="_blank">photodiary</a></li>
                        <li class="nav-menu__item"><a href="/minimo/pages/music.php" target="_blank">music</a></li>
                        <li class="nav-menu__item"><a href="/minimo/pages/travel.php" target="_blank">travel</a></li>
                    </ul>
                </nav>
            </section>
        </header>