<?php
   require_once "includes/head.php";
   require_once "includes/db.php";
   require_once "includes/header.php";
   require_once "includes/main.php";
   require_once "includes/footer.php";
?>

<!--<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php echo $config['title'] ?></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="mystyle.css" rel="stylesheet">
    </head>

        